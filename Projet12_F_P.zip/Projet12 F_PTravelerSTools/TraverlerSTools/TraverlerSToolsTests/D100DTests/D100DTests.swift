//
//  D100DTests.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 03/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
@testable import TraverlerSTools

class D100DTests: XCTestCase {

    func testIfNumberDice6NumberFace6ThenListOfResultsIsNotEmpty() {
        let mixTheDice = MixTheDice()

        let (numberList, total) = mixTheDice.calculatingRollsOfDice(numberOfDice: 6, numberOfFace: 6)
        XCTAssertTrue(numberList != [])
        XCTAssertTrue(total > 0)
        XCTAssertNotNil(mixTheDice.listOfResults)
    }
}
