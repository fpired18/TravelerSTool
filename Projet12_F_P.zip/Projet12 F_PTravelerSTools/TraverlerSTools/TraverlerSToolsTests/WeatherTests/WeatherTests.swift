//
//  WeatherTests.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
@testable import TraverlerSTools
import Alamofire

class WeatherTests: XCTestCase {

    func testGivenValueEntered_WhenEgalBourgesThenId_CitiesEgal6454979() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: FakeResponseDataWeather.error)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)
        weatherService.valueEntered = "Bourges"

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (_, _) in
            //Then
            XCTAssert( weatherService.idCities == "6454979")
            XCTAssert( weatherService.idGlobal == "5128581,l6454979")
            expectation.fulfill()
        }
    }

    func testGetWeatherShouldPostFailedCallbackIfError() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: FakeResponseDataWeather.error)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallbackIfNoData() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseOK,
                                        data: FakeResponseDataWeather.changeIncorrectData,
                                        error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallbackIfResponseKO() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseKO,
                                        data: FakeResponseDataWeather.changeCorrectData,
                                        error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallbackIfResponseCorrectAndNilData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseOK,
                                        data: nil,
                                        error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostSuccessCallbackIfNoErrorWithCorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseOK,
                                        data: FakeResponseDataWeather.changeCorrectData,
                                        error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)
        weatherService.valueEntered = "Paris"
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in

            //Then
            XCTAssertNotNil(success)
            XCTAssertTrue(weatherStruct != nil)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallBackIfIncorrectResponse() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseKO,
                                        data: FakeResponseDataWeather.changeIncorrectData,
                                        error: nil)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        // When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetWeatherShouldPostFailedCallBackIncorrectData() {
        // Given
        let fakeResponse = FakeResponse(response: FakeResponseDataWeather.responseOK,
                                        data: FakeResponseDataWeather.changeIncorrectData,
                                        error: FakeResponseDataWeather.error)
        let weatherSessionFake = WeatherSessionFake(fakeResponse: fakeResponse)
        let weatherService = WeatherService(weatherSession: weatherSessionFake)

        // When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        weatherService.getWeather { (success, weatherStruct) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
}
