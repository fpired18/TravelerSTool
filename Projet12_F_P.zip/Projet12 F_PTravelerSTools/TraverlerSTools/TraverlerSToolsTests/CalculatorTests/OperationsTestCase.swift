//
//  OperationsTestCase.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 30/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
@testable import TraverlerSTools

class OperationsTestCase: XCTestCase {
    var operations: Operations!
    var results: Results!
    override func setUp() {
        super.setUp()
        self.operations = Operations()
        self.results = Results()
    }

    func testGivenThisElements_WhenCallEqualButtonAction_ThenResultIsEgalThreeHundredFortyFiveDotFive() {
        operations.elements = ["1", "2", ".", "5", "+", "8", "5", "*", "4", "-", "2", "5", "/", "5"]
        _ = operations.equalButtonAction()
        //Then
        XCTAssertEqual(operations.result, "347.5")
    }

    func testGivenThisElements_WhenCallGroupElement_ThenElementsIsRegroup1() {
        operations.elements = ["1", "2", ".", "5", "+", "8", "5", "*", "4", "-", "2", "5", "/", "5"]

        //Then
        XCTAssertEqual(operations.groupElement(elements: &operations.elements),
                       ["12.5", "+", "85", "*", "4", "-", "25", "/", "5"])
        XCTAssertTrue(operations.priorityOperant)
    }

    func testGivenThisElements_WhenCallEqualButtonAction_ThenResultIsEgalSeventyThreeDotFive() {
        operations.elements = ["1", "2", ".", "5", "+", "8", "5", "-", "4", "-", "2", "5", "+", "5"]
        _ = operations.equalButtonAction()
        //Then
        XCTAssertEqual(operations.result, "73.5")
    }

    func testGivenThisElements_WhenCallGroupElement_ThenElementsIsRegroup2() {
        operations.elements = ["1", "2", ".", "5", "+", "8", "5", "-", "4", "-", "2", "5", "+", "5"]

        //Then
        XCTAssertEqual(operations.groupElement(elements: &operations.elements),
                       ["12.5", "+", "85", "-", "4", "-", "25", "+", "5"])
        XCTAssertFalse(operations.priorityOperant)
    }

    func testGivenThisElements_WhenCallEqualButtonAction_ThenResultIsEgalThirtySeventDotFive() {
        operations.elements = ["1", "5", "0", "%", "2", "5"]
        _ = operations.equalButtonAction()

        //Then
        XCTAssertEqual(operations.result, "37.5")
    }

    func testGivenThisElements_WhenCallEqualButtonAction_ThenResultIsEgalThirty() {
        operations.elements = ["2", "8", "+", "2", "2"]
        _ = operations.equalButtonAction()

        //Then
        XCTAssertEqual(operations.result, "50.0")
    }

    func testGivenThisElements_WhenCallEqualButtonActionAndOperateurIsKo_ThenResultIsEgalThirty() {
        operations.elements = ["2", "8", "§", "2", "2"]
        _ = operations.equalButtonAction()

        //Then
        let defaulte = results.resultOperation(left: 28, operand: "§", right: 22)
        XCTAssertEqual(defaulte, "Unknown operator !")
        XCTAssertEqual(operations.result, "")
    }

    func testGivenThisLastElements_WhenCallCanAddOperator_ThenCanAddOperatorIsEqualTrue() {
        operations.elements = ["1", "5", "0", "%", "2", "5", "*", "="]

        //Then
        XCTAssertNotEqual(operations.canAddOperator, false)
    }

    func testGivenThisOperator_WhenCallCanAddOperator_ThenElementIsEqualTrue() {
        operations.elements = ["1", "5", "0", "%", "2", "5"]

        //Then
        XCTAssertEqual(operations.canAddOperator, true)
    }

    func testGivenThisLastElements_WhenCallExpressionIsCorrect_ThenExpressionIsCorrectIsEqualTrue() {
        operations.elements = ["1", "5", "0", "%", "2", "5", "/"]

        //Then
        XCTAssertNotEqual(operations.expressionIsCorrect, true)
        XCTAssertFalse(operations.expressionIsCorrect)
    }

    func testGivenAlert_WhenCallErrorDetectionEqualOne_ThenAlerteEqualTrue() {
        let message = operations.errorDetection(choice: 1)

        //Then
        XCTAssertEqual(message, "An operator has already entered !")
    }

    func testGivenAlert_WhenCallErrorDetectionEqualTwo_ThenAlerteEqualTrue() {
        let message = operations.errorDetection(choice: 2)

        //Then
        XCTAssertEqual(message, "Enter a correct operation !")
    }

    func testGivenAlert_WhenCallErrorDetectionEqualThree_ThenAlerteEqualTrue() {
        let message = operations.errorDetection(choice: 3)

        //Then
        XCTAssertEqual(message, "Start a new calculation !")
    }

    func testGivenThisElements_WhenCallEqualButtonAction_ThenAlerteEqualTrue() {
        operations.elements = ["150", "/", "0"]
        _ = operations.priorityCalculation(elements: &operations.elements)

        //Then
        XCTAssertEqual(operations.alerte, "Impossible operation")
    }

    func testGivenAnEgualFirstElement_WhenEqualButtonAction_ThenExpressionHaveEnoughElementEgualFalse() {
        operations.elements = []

        //Then
        XCTAssertEqual(operations.expressionHaveResult, false)
        XCTAssertEqual(operations.expressionHaveEnoughElement, false)
        XCTAssertEqual(operations.canAddOperator, true)
        XCTAssertEqual(operations.expressionIsCorrect, true)
    }

    func testGivenThisElementsWithOneOperant_WhenTappedOneOtherOperant_ThenTheGuettersAreFalse() {
        operations.elements = ["+", "/"]

        //Then
        XCTAssertEqual(operations.expressionHaveResult, false)
        XCTAssertEqual(operations.expressionHaveEnoughElement, false)
        XCTAssertEqual(operations.canAddOperator, false)
        XCTAssertEqual(operations.expressionIsCorrect, false)
    }

    func testGivenClear_WhenCallClearButtonAction_ThenElementsIsEmpty() {
        operations.elements = ["1", "5", "0", "%", "2", "5"]
        operations.clearButtonAction()

        //Then
        XCTAssertNotEqual(operations.elements, [])
    }

    func testGivenThisElements_WhenCallGroupElement_ThenElementsIsRegroup3() {
        operations.elements = ["1", "5", "0", "%", "2", "5"]

        //Then
        XCTAssertEqual(operations.groupElement(elements: &operations.elements), ["150", "%", "25"])
        XCTAssertTrue(operations.priorityOperant)
    }

    func testGivenResultEqualTen_WhenCallMemoryButton_ThenMemoryPlusEqualResult() {
        operations.result = "10.0"
        operations.memoryButton(tag: 1)
        //Then
        XCTAssertEqual(Double(operations.result), operations.memoryPlus)
        XCTAssertEqual(operations.memoryMinus, 0)
    }

    func testGivenResultEqualMinusTen_WhenCallMemoryButton_ThenMemoryPlusEqualResult() {
        operations.result = "-10.0"
        operations.memoryButton(tag: 1)
        //Then
        XCTAssertNotEqual(Double(operations.result), operations.memoryPlus)
        XCTAssertEqual(operations.memoryMinus, 0)
    }

    func testGivenResultEqualTwenty_WhenCallMemoryButton_ThenMemoryMinusEqualResult() {
        operations.result = "20.0"
        operations.memoryButton(tag: 2)
        //Then
        XCTAssertNotEqual(Double(operations.result), operations.memoryMinus)
        XCTAssertEqual(operations.memoryPlus, 0)
    }

    func testGivenResultEqualMinusTwenty_WhenCallMemoryButton_ThenMemoryMinusEqualResult() {
        operations.result = "-20.0"
        operations.memoryButton(tag: 2)
        //Then
        XCTAssertEqual(Double(operations.result), operations.memoryMinus)
        XCTAssertEqual(operations.memoryPlus, 0)
    }

    func testGivenMemoryMinusEqualTwentyAndMemoryPlusEqual_WhenCallMemoryButton_ThenResultEqualResultFifty() {
        operations.memoryPlus = 30
        operations.memoryMinus = 20.0
        operations.memoryButton(tag: 3)
        //Then
        XCTAssertEqual(operations.result, "50.0")
        XCTAssertEqual(operations.memoryPlus, 0)
        XCTAssertEqual(operations.memoryMinus, 0)
    }

    func testLeftEqualTenAndRightEqualTwenty_WhenCallWithOperandPlus_ThenResultEqualThirty() {
        let result = results.resultOperation(left: 10, operand: "+", right: 20)

        //Then
        XCTAssertEqual(result, "30.0")
    }

    func testLeftEqualTenAndRightEqualTwenty_WhenCallWithOperandMinus_ThenResultEqualMinusTen() {
        let result = results.resultOperation(left: 10, operand: "-", right: 20)

        //Then
        XCTAssertEqual(result, "-10.0")
    }

    func testLeftEqualTenAndRightEqualTwenty_WhenCallWithOperandMultiply_ThenResultEqualTwoHundred() {
        let result = results.resultOperation(left: 10, operand: "*", right: 20)

        //Then
        XCTAssertEqual(result, "200.0")
    }

    func testLeftEqualTenAndRightEqualTwenty_WhenCallFonctionsWithOperandDivide_ThenResultEqualZerodotfive() {
        let result = results.resultOperation(left: 10, operand: "/", right: 20)

        //Then
        XCTAssertEqual(result, "0.5")
    }

    func testGivenThisElements_WhenCallExpressionHaveEnoughElement_ThenExpressionHaveEnoughElementIsFalse() {
        operations.elements = ["1", "2"]

        //Then
        XCTAssertFalse(operations.expressionHaveEnoughElement)
    }

    func testGivenThisElements_WhenCallExpressionHaveResult_ThenExpressionHaveResultIsTrue() {
        operations.elements = ["="]

        //Then
        XCTAssertTrue(operations.expressionHaveResult)
    }
}
