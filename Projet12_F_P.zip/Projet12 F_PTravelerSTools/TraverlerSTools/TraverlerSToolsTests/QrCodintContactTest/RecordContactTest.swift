//
//  RecordContactTest.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 30/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
import CoreData
@testable import TraverlerSTools

class RecordContactTest: XCTestCase {
    var recordContact = RecordContact()

    // MARK: - Properties

    lazy var mockContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "TravelerSTools")
        return container
    }()

    // MARK: - Helper Methods

    override func setUp() {
        Contact.deleteAll(viewContext: mockContainer.viewContext)
    }

    private func addContact(into managedObjectContext: NSManagedObjectContext) {
        //let newContact = Contact(context: managedObjectContext)
        recordContact.lastName = "Hugo"
        recordContact.firstName = "Victor"
        recordContact.address = "83 rue des Misérables"
        recordContact.postalCode = "25000"
        recordContact.city = "Besançon"
        recordContact.phone = "0626020285"
        recordContact.email = "victorhugo@ecrivain.com"
        Contact.save(recordContact: recordContact)
    }

    func testContactInFavoriteShouldReturnTrueIfAlreadyExist() {
        // Given
        let lastName = "Hugo"
        addContact(into: mockContainer.viewContext)
        try? mockContainer.viewContext.save()

        // When
        let response = Contact.contactAlreadyRecord(lastName: lastName)

        // Then
        XCTAssertEqual(response, true)
    }

    func testDeleteAllContactInPersistentContainer() {
        // Given
        addContact(into: mockContainer.viewContext)
        try? mockContainer.viewContext.save()

        // When
        Contact.deleteAll(viewContext: mockContainer.viewContext)

        // Then
        XCTAssertEqual(Contact.all, [])
    }

    func testDeleteOneContactInPersistentContainer() {
        // Given
        let lastName = "Hugo"
        addContact(into: mockContainer.viewContext)
        try? mockContainer.viewContext.save()

        // When
        Contact.delete(lastName: lastName)

        // Then
        XCTAssertEqual(Contact.all, [])
    }

    func testGenerateQrCodeIfRecordContactFullThenConcatenationIsOK() {
        // Given
        addContact(into: mockContainer.viewContext)
        try? mockContainer.viewContext.save()

        // When
        let concatenation = recordContact.generateQRCode(recordContact: recordContact)

        // Then
        XCTAssertEqual(concatenation, "Hugo Victor\nAdresse: 83 rue des Misérables\nC.P.: 25000\nVille: Besançon\nTel: 0626020285\nMail: victorhugo@ecrivain.com")
    }

    func testControlSeizureWhenTheWordHasAnAccentThenTheWordLoseThisAccent() {
        //Given
        let firstName = "Frédéric"

        // When
        let firstNameControl = recordContact.controleSeizure(enteredWord: firstName)

        // Then
        XCTAssertEqual(firstNameControl, "Frederic")
    }
}
