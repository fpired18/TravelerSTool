//
//  TranslateResponseData.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
class  FakeResponseDataTranslate {
    static var changeCorrectData: Data {
        let bundle = Bundle(for: FakeResponseDataTranslate.self)
        let url = bundle.url(forResource: "Translate", withExtension: "json")
        let data = (try? Data(contentsOf: url!)) ?? Data()
        return data
    }

    static let changeIncorrectData = "erreur".data(using: .utf8)!

    static let responseOK = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!,
                                            statusCode: 200, httpVersion: nil, headerFields: nil)!

    static let responseKO = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!,
                                            statusCode: 500, httpVersion: nil, headerFields: nil)!

    class TranslateError: Error {}
    static let error = TranslateError()

}
