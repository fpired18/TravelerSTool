//
//  TranslateTests.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
@testable import TraverlerSTools
import Alamofire

class TranslateTests: XCTestCase {

    func testGetTranslateShouldPostFailedCallbackIfError() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: FakeResponseDataTranslate.error)

        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(translateStruct)
            expectation.fulfill()
        }
    }

    func testGetTranslateShouldPostFailedCallbackIfNoData() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: nil)
        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(translateStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetTranslateShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataTranslate.responseOK,
                                        data: FakeResponseDataTranslate.changeIncorrectData,
                                        error: nil)
        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(translateStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetTranslateShouldPostFailedCallbackIfResponseKO() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataTranslate.responseKO,
                                        data: FakeResponseDataTranslate.changeCorrectData,
                                        error: nil)
        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(translateStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetTranslateShouldPostFailedCallbackIfResponseCorrectAndNilData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataTranslate.responseOK,
                                        data: nil,
                                        error: nil)
        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(translateStruct)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetTranslateShouldPostSuccessCallbackIfNoErrorWithCorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataTranslate.responseOK,
                                        data: FakeResponseDataTranslate.changeCorrectData,
                                        error: nil)
        let translateSessionFake = TranslateSessionFake(fakeResponse: fakeResponse)
        let translateService = TranslateService(translateSession: translateSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate { (success, translateStruct) in

            //Then
            XCTAssertNotNil(success)
            XCTAssertTrue(translateStruct != nil)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
}
