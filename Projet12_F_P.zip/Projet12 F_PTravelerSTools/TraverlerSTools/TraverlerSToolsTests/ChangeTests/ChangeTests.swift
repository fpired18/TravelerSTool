//
//  ChangeTests.swift
//  TraverlerSToolsTests
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import XCTest
@testable import TraverlerSTools
import Alamofire

class ChangeTests: XCTestCase {

    func testGetChangeShouldPostFailedCallbackIfError() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: FakeResponseDataChange.error)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        //wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallbackIfNoData() {
        //Given
        let fakeResponse = FakeResponse(response: nil, data: nil, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseOK,
                                        data: FakeResponseDataChange.changeIncorrectData, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallbackIfResponseKO() {
        //Given

        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseKO,
                                        data: FakeResponseDataChange.changeCorrectData, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallbackIfResponseCorrectAndNilData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseOK, data: nil, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostSuccessCallbackIfNoErrorWithCorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseOK,
                                        data: FakeResponseDataChange.changeCorrectData, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)
        changeService.valueEntered = 254
        changeService.nationalityChange = "USD"

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertTrue(success)
            XCTAssertNotNil(quote)
            XCTAssertEqual(changeService.valueEntered, (254))
            XCTAssertEqual(changeService.valueReturn, (281.293824))  //1.107456
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallBackIfIncorrectResponse() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseKO,
                                        data: FakeResponseDataChange.changeIncorrectData, error: nil)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

    func testGetChangeShouldPostFailedCallBackIncorrectData() {
        //Given
        let fakeResponse = FakeResponse(response: FakeResponseDataChange.responseOK,
                                        data: FakeResponseDataChange.changeIncorrectData,
                                        error: FakeResponseDataChange.error)
        let changeSessionFake = ChangeSessionFake(fakeResponse: fakeResponse)
        let changeService = ChangeService(changeSession: changeSessionFake)

        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        changeService.getChange { (success, quote) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(quote)
            expectation.fulfill()
        }
        //wait(for: [expectation], timeout: 0.01)
    }
}
