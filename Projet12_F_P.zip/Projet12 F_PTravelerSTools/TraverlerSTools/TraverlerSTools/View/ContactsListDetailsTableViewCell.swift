//
//  ContactsListDetailsTableViewCell.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 17/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit

class ContactsListDetailsTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var postalCodeTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!

    // MARK: - Methods

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(contact: Contact) {
        lastNameTextField.text = contact.lastName
        firstNameTextField.text = contact.firstName
        addressTextField.text = contact.address
        postalCodeTextField.text = contact.postalCode
        cityTextField.text = contact.city
        phoneTextField.text = contact.phone
        emailTextField.text = contact.email
    }
}
