//
//  D100DViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 03/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit
import CoreMotion

class D100DViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var numberOfDices: UITextField!
    @IBOutlet weak var numberOfFaces: UITextField!
    @IBOutlet weak var totalDisplay: UITextField!
    @IBOutlet weak var launchButton: UIButton!
    @IBOutlet weak var gameMatDisplay: UITextView!

    // MARK: - Properties
    var mixTheDice = MixTheDice()
    var motionManager = CMMotionManager()

    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func actionTapLaunchButton() {
        if numberOfDices.text != "" && numberOfFaces.text != "" {
            if let numberOfDice = Int(numberOfDices.text!) {
                if let numberOfFace = Int(numberOfFaces.text!) {
                    let (numberList, total) = mixTheDice.calculatingRollsOfDice(numberOfDice: numberOfDice,
                                                                                numberOfFace: numberOfFace)
                    gameMatDisplay.text = String(describing: numberList)
                    totalDisplay.text = String(describing: total)
                }
            }
        } else {
            gameMatDisplay.text = "Unable to roll dice until both parapeters are completed !"
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    override func viewDidAppear(_ animated: Bool) {
        motionManager.accelerometerUpdateInterval = 0.2

        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, _) in
            if let myData = data {
                if myData.acceleration.x > 0.32 {
                    self.actionTapLaunchButton()
                }
            }
        }
    }

    // MARK: - Actions
    @IBAction func tapLaunchButton(_ sender: UIButton) {
        sender.flashBis()
        actionTapLaunchButton()
    }
}
