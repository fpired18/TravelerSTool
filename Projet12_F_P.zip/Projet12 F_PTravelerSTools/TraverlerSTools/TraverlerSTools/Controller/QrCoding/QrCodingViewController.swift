//
//  QrCodingViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit
import Foundation

class QrCodingViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var postalCodeTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var qrCodeImageView: UIImageView!

    // MARK: - Properties
    var recordContact = RecordContact()
    var contact: Contact!
    var filter: CIFilter!
    var origineData = false
    var qrCodeImageViewOrigine: CGPoint!

    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        addPanGesture(view: qrCodeImageView)
        qrCodeImageViewOrigine = qrCodeImageView.frame.origin
    }

    func addPanGesture(view: UIView) {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(sender:)))
        view.addGestureRecognizer(pan)
    }

    @objc func handlePan(sender: UIPanGestureRecognizer) {
        let fileView = sender.view!

        switch sender.state {
        case .began, .changed:
            moveViewWithPan(view: fileView, sender: sender)
        case .ended:
            if fileView.frame.origin.x >= view.frame.origin.x {
                returnViewToOrigin(view: qrCodeImageView)
                if recordContact.lastName != "" {
                    saveContact()
                } else {
                    presentAlert(title: "Error", message: "Unable to save an unnamed contact !")
                }
            } else if fileView.frame.origin.y >= view.frame.origin.y {
                returnViewToOrigin(view: qrCodeImageView)
                if qrCodeImageView.image != nil {
                    toSendQrCoding(qrCodeImageView)
                } else {
                    presentAlert(title: "Error", message: "Unable to send the Qr Code !")
                }
            } else if fileView.frame.origin.x <= view.frame.origin.x {
                returnViewToOrigin(view: qrCodeImageView)
                if qrCodeImageView.image != nil {
                    printQRCode()
                } else {
                    presentAlert(title: "Error", message: "Unable to printed the Qr Code !")
                }
            }
        default:
            break
        }
    }

    func moveViewWithPan(view: UIView, sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: view)
        view.center = CGPoint(x: view.center.x + translation.x, y: view.center.y + translation.y)
        sender.setTranslation(CGPoint.zero, in: view)
    }

    func returnViewToOrigin(view: UIView) {
        UIView.animate(withDuration: 0.3, animations: {
            view.frame.origin = self.qrCodeImageViewOrigine
        })
    }

    func deleteView(view: UIView) {
        UIView.animate(withDuration: 0.3, animations: {
            view.alpha = 0.0
        })
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if origineData {
            displayContactData()
        }
    }

    @objc func toSendQrCoding(_ : AnyObject) {
        // MENU OF SHARING APPLICATIONS
        UIGraphicsBeginImageContext(qrCodeImageView.frame.size)
        qrCodeImageView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        let activityVC = UIActivityViewController.init(activityItems: [image!], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)

    }

    @objc func printQRCode() {
        if qrCodeImageView.image != nil {
            let printController = UIPrintInteractionController.shared
            let printInfo = UIPrintInfo(dictionary: nil)
            printInfo.outputType = .photo
            printInfo.jobName = "printing an image"
            printController.printInfo = printInfo
            printController.printingItem = qrCodeImageView.image
            printController.present(animated: true) { (_, isPrinted, error) in
                if error == nil {
                    if isPrinted {
                        print("image is printed")
                    } else {
                        print("image is not printed")
                    }
                }
            }
        } else {
            presentAlert(title: "Error", message: "Unable to print the Qr Code !")
        }
    }

    func dataAssignement() -> RecordContact {
        //let recordContact = RecordContact()

        if var lastName = lastNameTextField.text {
            lastName = recordContact.controleSeizure(enteredWord: lastName)
            recordContact.lastName = lastName
        }

        if var firstName = firstNameTextField.text {
            firstName = recordContact.controleSeizure(enteredWord: firstName)
            recordContact.firstName = firstName
        }

        if var address = addressTextField.text {
            address = recordContact.controleSeizure(enteredWord: address)
            recordContact.address = address
        }

        if var postalCode = postalCodeTextField.text {
            postalCode = recordContact.controleSeizure(enteredWord: postalCode)
            recordContact.postalCode = postalCode
        }

        if var city = cityTextField.text {
            city = recordContact.controleSeizure(enteredWord: city)
            recordContact.city = city
        }

        if var phone = phoneTextField.text {
            phone = recordContact.controleSeizure(enteredWord: phone)
            recordContact.phone = phone
        }

        if var email = emailTextField.text {
            email = recordContact.controleSeizure(enteredWord: email)
            recordContact.email = email
        }
        return recordContact
    }

    // MARK: - Private method
    private func saveContact() {
        let recordContact = dataAssignement()
        if recordContact.lastName != "" {
            if Contact.contactAlreadyRecord(lastName: recordContact.lastName) {
                presentAlert(title: "Warning", message: "This contact was already record !")
            } else {
                Contact.save(recordContact: recordContact)
            }
        } else {
            presentAlert(title: "Error", message: "Unable to save an unnamed contact !")
        }
    }

    private func generateQrCoding() {
        let recordContact = dataAssignement()
        let concatenation = recordContact.generateQRCode(recordContact: recordContact)
        let data = concatenation.data(using: .ascii, allowLossyConversion: false)
        if data != nil {
            filter = CIFilter(name: "CIQRCodeGenerator")
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 10, y: 10)
            let image = UIImage(ciImage: filter.outputImage!.transformed(by: transform))
            qrCodeImageView.image = image
        }
    }

    private func displayContactData() {
        lastNameTextField.text = contact.lastName
        firstNameTextField.text = contact.firstName
        addressTextField.text = contact.address
        postalCodeTextField.text = contact.postalCode
        cityTextField.text = contact.city
        phoneTextField.text = contact.phone
        emailTextField.text = contact.email
    }

    // MARK: - Actions
    @IBAction func tapGenerateQrCoding(_ sender: UIButton) {
        sender.pulsate()
        generateQrCoding()
        // a regarder https://youtu.be/4Zf9dHDJ2yU
    }

    @IBAction func tapRecordContact(_ sender: UIButton) {
        sender.pulsate()
        saveContact()
    }

    @IBAction func dissmissKeyboard(_ sender: UITapGestureRecognizer) {
        lastNameTextField.resignFirstResponder()
        firstNameTextField.resignFirstResponder()
        addressTextField.resignFirstResponder()
        postalCodeTextField.resignFirstResponder()
        cityTextField.resignFirstResponder()
        phoneTextField.resignFirstResponder()
        emailTextField.resignFirstResponder()
    }

    @IBAction func tapPrintQRCode(_ sender: UIButton) {
        sender.shake()
        printQRCode()
    }

    @IBAction func tapToSend(_ sender: UIButton) {
        sender.shake()
        toSendQrCoding(qrCodeImageView)
    }
}
