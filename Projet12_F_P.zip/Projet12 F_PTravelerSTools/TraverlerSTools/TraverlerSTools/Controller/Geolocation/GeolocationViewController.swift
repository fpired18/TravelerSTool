//
//  GeolocationViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 29/11/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import AVFoundation

class CellClass: UITableViewCell {
}

class GeolocationViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var btnSelectMouveMode: UIButton!
    @IBOutlet weak var directionTextField: UITextView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var mapView: MKMapView!

    // MARK: - Properties
    let transparentView = UIView()
    let tableView = UITableView()
    var selectedButton = UIButton()
    var dataSource = ["Automobile", "Walking", "Any", "Transit"]
    let locationManager = CLLocationManager() //creation of a manager to use the location
    var currentCoordinate: CLLocationCoordinate2D!
    var steps = [MKRoute.Step]()
    let speechSynthesizer = AVSpeechSynthesizer()
    var stepCounter = 0

    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CellClass.self, forCellReuseIdentifier: "Cell")
        // location sharing
        locationManager.requestAlwaysAuthorization()
        // configuration of the manager
        locationManager.delegate = self
        // setting the search accuracy
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        // localization start
        locationManager.startUpdatingLocation()
    }

    func getDirections(to destination: MKMapItem) {
        let sourcePlacemark = MKPlacemark(coordinate: currentCoordinate)
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)

        let directionsRequest = MKDirections.Request()
        directionsRequest.source = sourceMapItem
        directionsRequest.destination = destination

        switch selectedButton.titleLabel?.text {
        case "Automobile":
            directionsRequest.transportType = .automobile
        case "Walking":
            directionsRequest.transportType = .walking
        case "Transit":
            directionsRequest.transportType = .transit
        case "Any":
            directionsRequest.transportType = .any
        default:
            break
        }

        let directions = MKDirections(request: directionsRequest)
        directions.calculate { (response, _) in
            guard let response = response else { return }
            guard let primaryRoute = response.routes.first else { return }

            self.mapView.addOverlay(primaryRoute.polyline)
            self.locationManager.monitoredRegions.forEach({ self.locationManager.stopMonitoring(for: $0) })
            // printing of each stage of the route
            self.steps = primaryRoute.steps
            for index in 0 ..< primaryRoute.steps.count {
                let step = primaryRoute.steps[index]
                print(step.instructions)
                print(step.distance)
                let region = CLCircularRegion(center: step.polyline.coordinate,
                                              radius: 20,
                                              identifier: "\(index)")
                self.locationManager.stopMonitoring(for: region)
                let circle = MKCircle(center: region.center, radius: region.radius)
                self.mapView.addOverlay(circle)
            }

            let initialMessage1 = "Dans \(self.steps[0].distance) mètres,"
            let initialMessage2 = "\(self.steps[0].instructions) puis dans \(self.steps[1].distance) mètres,"
            let initialMessage = "\(self.steps[1].instructions)." + initialMessage1 + initialMessage2
            self.directionTextField.text = initialMessage
            // sound of the message
            let speechUtterance = AVSpeechUtterance(string: initialMessage)
            self.speechSynthesizer.speak(speechUtterance)
            self.stepCounter += 1
        }
    }

    func addTransparentView(frames: CGRect) {
        let window = UIApplication.shared.keyWindow
        transparentView.frame = window?.frame ?? self.view.frame
        self.view.addSubview(transparentView)
        // setting the size of the drop-down menu
        tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        self.view.addSubview(tableView)
        tableView.layer.cornerRadius = 5
        //darkening of main view
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        tableView.reloadData()
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(removeTransparentView))
        transparentView.addGestureRecognizer(tapgesture)
        transparentView.alpha = 0
        UIView.animate(withDuration: 0.4, delay: 0.1, usingSpringWithDamping: 1.0,
                       initialSpringVelocity: 1.0,
                       options: .curveEaseInOut, animations: { self.transparentView.alpha = 0.5
                        self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height + 5,
                                                      width: frames.width, height: CGFloat(self.dataSource.count * 50))
        }, completion: nil )
    }

    @objc func removeTransparentView() {
        //recovery of travel mode
        let frames = selectedButton.frame
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0,
                       initialSpringVelocity: 1.0, options: .curveEaseInOut,
                       animations: { self.transparentView.alpha = 0
                        self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height,
                                                      width: frames.width, height: 0)
        }, completion: nil )
    }

    // Reset of all components
    func resetMapView() {
        mapView.removeOverlays(mapView.overlays)
        steps.removeAll()
        searchBar.text = ""
        directionTextField.text = ""
    }

    // MARK: - Actions
    @IBAction func tapSelectMouveMode(_ sender: UIButton) {
        sender.flash()
        selectedButton = btnSelectMouveMode
        addTransparentView(frames: btnSelectMouveMode.frame)
    }

    @IBAction func resetMap(_ sender: UIButton) {
        sender.shake()
        self.viewDidLoad()
        resetMapView()
    }
}

extension GeolocationViewController: CLLocationManagerDelegate {
    //position update
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // locations = array containing all localization updates
        manager.stopUpdatingLocation()
        guard let currentLocation = locations.first else { return }
        currentCoordinate = currentLocation.coordinate
        mapView.userTrackingMode = .followWithHeading
    }

    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("ENTERED")
        stepCounter += 1
        if stepCounter < steps.count {
            let currentStep = steps[stepCounter]
            let message = "Dans \(currentStep.distance) mètres, \(currentStep.instructions)"
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynthesizer.speak(speechUtterance)
        } else {
            let message = "Vous êtes arrivé à votre destination"
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynthesizer.speak(speechUtterance)
            stepCounter = 0
            locationManager.monitoredRegions.forEach ({ self.locationManager.stopMonitoring(for: $0) })
        }
    }
}

extension GeolocationViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        let localSearchRequest = MKLocalSearch.Request()
        localSearchRequest.naturalLanguageQuery = searchBar.text
        // map accuracy statement
        let region = MKCoordinateRegion(center: currentCoordinate,
                                        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        localSearchRequest.region = region
        let localSearch = MKLocalSearch(request: localSearchRequest)
        localSearch.start { (response, _) in
            guard let response = response else { return }
            guard let firstMapItem = response.mapItems.first else { return }
            self.getDirections(to: firstMapItem)
        }
    }
}

extension GeolocationViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        //configuration of the course line, here in blue
        if overlay is MKPolyline {
            let renderer = MKPolylineRenderer(overlay: overlay)
            renderer.strokeColor = .blue
            renderer.lineWidth = 5
            return renderer
        }
        //configuration of junction points
        if overlay is MKCircle {
            let renderer = MKCircleRenderer(overlay: overlay)
            renderer.strokeColor = .green
            renderer.fillColor = .red
            renderer.alpha = 0.5
            return renderer
        }
        return MKOverlayRenderer()
    }
}

extension GeolocationViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = dataSource[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedButton.setTitle(dataSource[indexPath.row], for: .normal)
        removeTransparentView()
    }
}
