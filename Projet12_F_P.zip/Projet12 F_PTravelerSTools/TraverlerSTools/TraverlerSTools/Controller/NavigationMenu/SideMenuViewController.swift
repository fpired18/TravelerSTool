//
//  SideMenuViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 28/11/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit

class SideMenuViewController: UITableViewController {

    // MARK: - Methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)

        switch indexPath.row {
        case 0:
            NotificationCenter.default.post(name: NSNotification.Name("ShowGeolocation"), object: nil)
        case 1:
            NotificationCenter.default.post(name: NSNotification.Name("ShowTraductor"), object: nil)
        case 2:
            NotificationCenter.default.post(name: NSNotification.Name("ShowWeather"), object: nil)
        case 3:
            NotificationCenter.default.post(name: NSNotification.Name("ShowQrCodeCoordinates"), object: nil)
        case 4:
            NotificationCenter.default.post(name: NSNotification.Name("ShowContactsList"), object: nil)
        case 5:
            NotificationCenter.default.post(name: NSNotification.Name("ShowScanner"), object: nil)
        case 6:
            NotificationCenter.default.post(name: NSNotification.Name("ShowDieWithoutDie"), object: nil)
        default:
            break
        }
    }
}
