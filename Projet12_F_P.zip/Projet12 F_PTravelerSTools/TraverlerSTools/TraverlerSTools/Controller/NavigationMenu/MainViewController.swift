//
//  MainViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 28/11/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
// COUCOU

import UIKit

class MainViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var textView: UITextView!
    @IBOutlet var numberButtons: [UIButton]!
    @IBOutlet weak var enterAmountTextField: UITextField!
    @IBOutlet weak var convertButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var sortieAmountLabel: UILabel!
    @IBOutlet weak var choiceNationalityChangePickerView: UIPickerView!

    // MARK: - Properties
    var numberGlobal = 0.0
    var changeService = ChangeService()
    var operation = Operations()
    var message = ""
    var tag = 0
    var amountChange = ""

    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        toggleActivityIndicator(shown: false)
        textView.text = ""
        operation.elements = []
        let name = Notification.Name(rawValue: "ErrorDetection")
        // detection de contact sur les différents boutons renvoyant vers des fonctions équipé de ségué
        NotificationCenter.default.addObserver(self, selector: #selector(alerteMethode), name: name, object: nil)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showGeolocation),
                                               name: NSNotification.Name("ShowGeolocation"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showTraductor),
                                               name: NSNotification.Name("ShowTraductor"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showWeather),
                                               name: NSNotification.Name("ShowWeather"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(dieWithoutDie),
                                               name: NSNotification.Name("ShowDieWithoutDie"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showQrCode),
                                               name: NSNotification.Name("ShowQrCodeCoordinates"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showContactsList),
                                               name: NSNotification.Name("ShowContactsList"),
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(showScanner),
                                               name: NSNotification.Name("ShowScanner"),
                                               object: nil)
    }

    @objc func showGeolocation() {
        performSegue(withIdentifier: "ShowGeolocation", sender: nil)
    }

    @objc func showTraductor() {
        performSegue(withIdentifier: "ShowTraductor", sender: nil)
    }

    @objc func showWeather() {
        performSegue(withIdentifier: "ShowWeather", sender: nil)
    }

    @objc func dieWithoutDie() {
        performSegue(withIdentifier: "ShowDieWithoutDie", sender: nil)
    }

    @objc func showQrCode() {
        performSegue(withIdentifier: "ShowQrCodeCoordinates", sender: nil)
    }

    @objc func showContactsList() {
        performSegue(withIdentifier: "ShowContactsList", sender: nil)
    }

    @objc func showScanner() {
        performSegue(withIdentifier: "ShowScanner", sender: nil)
    }

    @objc func alerteMethode() {
        textView.text = ""
        alerteMethod(tag: 2)
    }

    @objc func alerteMethod(tag: Int) {
        textView.text.append(" Error")
        message = operation.errorDetection(choice: tag)
        presentAlert(title: "Error", message: message)
    }

    func numberRecord(_ sender: UIButton) -> String {
        let enterNumber = sender.title(for: .normal)!
        guard sender.title(for: .normal) != nil else {
            return ""
        }
        operation.elements.append(enterNumber)
        return enterNumber
    }

    func displaysAndRecord(viewText: String, elements: String) {
        operation.elements.append(elements)
        textView.text.append(viewText)
    }

    func searchConversion() {
        changeService.getChange { (success, quote) in
            self.toggleActivityIndicator(shown: false)

            if success, let quote = quote {
                self.update(quote: quote)
            } else {
                self.presentAlert(title: "Error", message: "The Change download failed today!")
            }
        }
    }

    func update(quote: Quote) {
        self.sortieAmountLabel.text = String(quote.returnValue)
        amountChange = String(quote.returnValue)
    }

    // MARK: - Private Methods
    private func toggleActivityIndicator(shown: Bool) {
        // button inverter with activity indicator
        convertButton.isHidden = shown
        activityIndicator.isHidden = !shown
    }

    // MARK: - Actions
    @IBAction func onMoreTapped() {
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }

    @IBAction func tappedNumberButton(_ sender: UIButton) {
        guard sender.title(for: .normal) != nil else {
            return
        }
        if operation.expressionHaveResult {
            textView.text = ""
            operation.elements = []
        }
        textView.text.append(numberRecord(sender))
    }

    @IBAction func tappedClear(_ sender: UIButton) {
        textView.text = ""
        operation.clearButtonAction()
    }

    @IBAction func tappedAdditionButton(_ sender: UIButton) {
        tag = sender.tag
        if operation.canAddOperator {
            displaysAndRecord(viewText: " + ", elements: "+")
        } else {
            alerteMethod(tag: tag)
        }
    }

    @IBAction func tappedSubstractionButton(_ sender: UIButton) {
        tag = sender.tag
        if operation.canAddOperator {
            displaysAndRecord(viewText: " - ", elements: "-")
        } else {
            alerteMethod(tag: tag)
        }
    }

    @IBAction func tappedMultiplicationButton(_ sender: UIButton) {
        tag = sender.tag
        if operation.canAddOperator {
            displaysAndRecord(viewText: " * ", elements: "*")
        } else {
            alerteMethod(tag: tag)
        }
    }

    @IBAction func tappePercentage(_ sender: UIButton) {
        tag = sender.tag
        if operation.canAddOperator {
            displaysAndRecord(viewText: " % ", elements: "%")
        } else {
            alerteMethod(tag: tag)
        }
    }

    @IBAction func tappedDivisionButton(_ sender: UIButton) {
        tag = sender.tag
        if operation.canAddOperator {
            displaysAndRecord(viewText: " / ", elements: "/")
        } else {
            alerteMethod(tag: tag)
        }
    }

    @IBAction func tappedEqualButton(_ sender: UIButton) {
        tag = sender.tag
        guard operation.expressionIsCorrect else {
            tag = 2
            alerteMethod(tag: tag)
            operation.elements = []
            return
        }
        guard operation.expressionHaveEnoughElement else {
            alerteMethod(tag: tag)
            return
        }
        if operation.expressionIsCorrect || operation.expressionHaveEnoughElement {
            textView.text.append(" = \(operation.equalButtonAction())")
        }
    }

    @IBAction func tappedMemoryButton(_ sender: UIButton) {
        operation.memoryButton(tag: sender.tag)
        textView.text = ""
        textView.text.append("\(operation.result)")
    }

    @IBAction func didTapConvertButton(_ sender: Any) {
        toggleActivityIndicator(shown: true)
        if let valueEntered = Double(enterAmountTextField.text!) {
            changeService.valueEntered = valueEntered
            let cityIndex = choiceNationalityChangePickerView.selectedRow(inComponent: 0)
            changeService.nationalityChange = changeService.listOfNationalId[cityIndex]
        }
        searchConversion()
    }

    @IBAction func dissmissKeyboard(_ sender: UITapGestureRecognizer) {
        enterAmountTextField.resignFirstResponder()
        textView.resignFirstResponder()
    }

    @IBAction func unwindToWelcome(segue: UIStoryboardSegue) {
    }
}

extension MainViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //delimiting the size of the pickerview
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //power of the pickerview by the controller
        return changeService.listOfNationalId.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return changeService.listOfNationalId[row]
    }
}
