//
//  TranslateViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit

class TranslateViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var translateButton: UIButton!
    @IBOutlet weak var textToTranslateUITextView: UITextView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var languagePickerView: UIPickerView!
    @IBOutlet weak var outputTextTranslateUITextView: UITextView!

    // MARK: - Properties
    var translateService = TranslateService()

    // MARK: - Methods
    override func viewDidLoad() {
        toggleActivityIndicator(shown: false)
    }

    func searchConversion() {
        translateService.getTranslate { (success, translate) in
            self.toggleActivityIndicator(shown: false)

            if success, let translate = translate {
                self.update(translate: translate)
            } else {
                self.presentAlert(title: "Error", message: "The Change download failed today!")
            }
        }
    }

    private func toggleActivityIndicator(shown: Bool) {
        // button inverter with activity indicator
        translateButton.isHidden = shown
        activityIndicator.isHidden = !shown
    }

    func update(translate: Translate) {
        // refresh the view
        let retourTranslate = translate.data.translations[0].translatedText

        self.outputTextTranslateUITextView.text = String(retourTranslate)
    }

    // MARK: - Actions
    @IBAction func didTapTranslateButton(_ sender: UIButton) {
        sender.pulsate()
        sender.layer.shadowOpacity = 0.5
        sender.layer.shadowRadius = 6
        if let valueEntered = textToTranslateUITextView.text {
            // transfer of the two entries to the model
            if valueEntered == "" {
                presentAlert(title: "Warning", message: "You don't have enter a word")
            } else {
                toggleActivityIndicator(shown: true)
                translateService.valueEntered = valueEntered
                let languageIndex = languagePickerView.selectedRow(inComponent: 0)
                translateService.choiceLanguage = translateService.languagesPossible[languageIndex]
            }
        }
        searchConversion()
    }

    @IBAction func dissmissKeyboard(_ sender: UITapGestureRecognizer) {
        textToTranslateUITextView.resignFirstResponder()
    }
}

extension TranslateViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //delimiting the size of the pickerview
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //power of the pickerview by the controller
        return translateService.languagesPossible.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return translateService.languagesPossible[row]
    }
}
