//
//  WeatherViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit

class WeatherViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var choiceCityPickerView: UIPickerView!
    @IBOutlet weak var localTemperatureLabel: UILabel!
    @IBOutlet weak var localDescriptionLabel: UILabel!
    @IBOutlet weak var weatherButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var temperatureLabelNewYork: UILabel!
    @IBOutlet weak var descriptionLabelNewYork: UILabel!

    // MARK: - Properties
    var weatherService = WeatherService()

    // MARK: - Methods
    override func viewDidLoad() {
        toggleActivityIndicator(shown: false)
    }

    func searchWeather() {
        weatherService.getWeather { (success, weatherStruct) in
            self.toggleActivityIndicator(shown: false)

            if success, let weatherStruct = weatherStruct {
                self.update(weatherStruct: weatherStruct)
            } else {
                self.presentAlert(title: "Warning", message: "The Weather download failed today!")
            }
        }
    }

    private func toggleActivityIndicator(shown: Bool) {
        // button inverter with activity indicator
        weatherButton.isHidden = shown
        activityIndicator.isHidden = !shown
    }

    func update(weatherStruct: WeatherStruct) { // refresh the view
        // limitation of the number of digits behind the decimal point
        self.localTemperatureLabel.text = String(format: "%.2f", weatherStruct.list[1].main.temp) + " °C"
        self.localDescriptionLabel.text = weatherStruct.list[1].weather[0].description
        self.descriptionLabelNewYork.text = weatherStruct.list[0].weather[0].description
        self.temperatureLabelNewYork.text = String(format: "%.2f", weatherStruct.list[0].main.temp) + " °C"
    }

    // MARK: - Actions
    @IBAction func didTapWeathertButton(_ sender: UIButton) {
        sender.shake()
        toggleActivityIndicator(shown: true)
        let compte = weatherService.idCityPossible.count
        print("The number of items recorded: \(compte)")
        let cityIndex = choiceCityPickerView.selectedRow(inComponent: 0)
        weatherService.valueEntered = weatherService.idCityPossible[cityIndex]
        searchWeather()
    }
}

extension WeatherViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //delimiting the size of the pickerview
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //power of the pickerview by the controller
        return weatherService.idCityPossible.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return weatherService.idCityPossible[row]
    }
}
