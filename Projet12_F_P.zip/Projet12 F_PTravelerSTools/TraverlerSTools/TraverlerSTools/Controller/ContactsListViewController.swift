//
//  ViewController.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 28/11/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import UIKit
import CoreData

class ContactsListViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var dataTableView: UITableView!

    // MARK: - Properties
    var contact = Contact.all
    var selectedRow: IndexPath?

    // MARK: - Actions
    @IBAction func tapDeletedAll(_ sender: Any) {
        Contact.deleteAll()
        contact = Contact.all
        dataTableView.reloadData()
    }

    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        dataTableView.reloadData()
    }

    override func viewWillAppear(_ animated: Bool) {
        self.dismiss(animated: true, completion: nil)
        super.viewWillAppear(animated)
        contact = Contact.all
        if contact.count >= 0 {
            dataTableView.reloadData()
        }
        if contact.count == 0 {
            presentAlert(title: "Warning", message: "Your list is empty !")
        }
    }
}

extension ContactsListViewController: UITableViewDataSource {
    // - Initialize the section number
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    // - Referencing the source and number of data
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contact.count
    }

    // - Creating and Inserting a cell in the tableView
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PresentDataCell",
                                                 for: indexPath) as? ContactsListDetailsTableViewCell
        cell?.configure(contact: contact[indexPath.row])
        return cell!
    }
}

extension ContactsListViewController: UITableViewDelegate {
    // - Deletion of a cell by lateral slip
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if let record = contact[indexPath.row].lastName {
                contact.remove(at: indexPath.row)
                Contact.delete(lastName: record)
                self.contact = Contact.all
                dataTableView.deleteRows(at: [indexPath], with: .automatic)
            }
        }
    }

    // - To the selection send the data to the indexPath by the segue identifier "ShowDetailData"
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedRow = indexPath
        performSegue(withIdentifier: "ShowDetailData", sender: self)
    }

    // - Destination and assignment of data
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDetailData" {
            if let destinationVC = segue.destination as? QrCodingViewController {
                if let row = self.dataTableView.indexPathForSelectedRow?.row {
                    let contactToSendData = contact[row]
                    destinationVC.origineData = true
                    destinationVC.contact = contactToSendData
                }
            }
        }
    }
}
