//
//  Results.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

class Results {

    func resultOperation (left: Double, operand: String, right: Double) -> String {
        var result = ""
        switch operand {
        case "+": result = String(left + right)
        case "-": result = String(left - right)
        case "*": result = String(left * right)
        case "/": result = String(left / right)
        case "%": result = String(left * (right / 100))
        default: result = "Unknown operator !"
        }
        return String(result)
    }
}
