//
//  Operations.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation 

class Operations {

    // MARK: - Properties
    var results = Results()
    var leftFloat = 0.0; var rightFloat = 0.0; var memoryPlus = 0.0; var memoryMinus = 0.0
    var priorityOperant = false; var secondTime = false; var firstTime = true
    var elements = [String]()
    var longElements = 0; var firstPassage = 0; var loop = 0; var longLoop = 0; var protectLoop = 0
    var safeguard = ""; var operand = ""; var number = ""; var alerte = ""; var result = ""
    var expressionHaveResult: Bool {
        return elements.firstIndex(of: "=") != nil
    }
    var expressionHaveEnoughElement: Bool {
        return elements.count >= 3
    }
    var canAddOperator: Bool {
        return elements.last != "+" && elements.last != "-" && elements.last != "*"
            && elements.last != "/" && elements.last != "%"
    }
    // Error check computed variables
    var expressionIsCorrect: Bool {
        return elements.last != "+" && elements.last != "-" && elements.last != "*"
            && elements.last != "/" && elements.last != "%"
    }

    // MARK: - Methods
    func errorDetection(choice: Int) -> String {
        switch choice {
        case 1:
            alerte = ("An operator has already entered !")
            clearButtonAction()
        case 2:
            alerte = ("Enter a correct operation !")
            clearButtonAction()
        case 3:
            alerte = ("Start a new calculation !")
            clearButtonAction()
        default:
            break
        }
        return alerte
    }

    func clearButtonAction() {
        priorityOperant = false; secondTime = false; firstTime = true
        leftFloat = 0.0; rightFloat = 0.0
        longElements = 0; firstPassage = 0; loop = 0; longLoop = 0; protectLoop = 0
        safeguard = ""; operand = ""; number = ""
    }

    func equalButtonAction() -> String {
        elements = groupElement(elements: &elements)
        // Iterate over operations while an operand still here
        while elements.count > 1 {
            if priorityOperant {
                priorityOperant = false
                elements = priorityCalculation(elements: &elements)
            }
            if !priorityOperant {
                elements = noPriorityCalculation(elements: &elements)
            }
            elements = Array(elements.dropFirst(elements.count)); elements.append("=")
            //to leave the loop the array is emptied
        }
        clearButtonAction()
        return String(result)
    }

    func groupElement(elements: inout [String]) -> [String] {
        longElements = elements.count
        for _ in 0..<longElements {
            if elements[loop] == "+" || elements[loop] == "-" || elements[loop] == "*"
                || elements[loop] == "/" || elements[loop] == "%" {
                if elements[loop] == "*" || elements[loop] == "/" || elements[loop] == "%" {
                    priorityOperant = true
                }
                if firstTime {
                    safeguard = number; firstTime = false
                }
                elements.append(number)
                elements.append(elements[loop])
                for _ in 0...longLoop where protectLoop != longElements {
                    elements.remove(at: 0)
                }
                longLoop = 0; loop = 0; number = ""; protectLoop += 1
            } else {
                number += elements[loop]; longLoop += 1; loop += 1; protectLoop += 1
                if protectLoop == longElements {
                    elements.append(number)
                    for _ in 0...longLoop-1 {
                        elements.remove(at: 0)
                    }
                }
            }
        }
        return elements
    }

    func priorityCalculation(elements: inout [String]) -> [String] {
        let longElements = elements.count; var loop = 0
        for _ in 0..<longElements where loop <= elements.count-1 {
            if elements[loop] == "*" || elements[loop] == "/" || elements[loop] == "%" {
                leftFloat = Double(elements[loop-1])!; rightFloat = Double(elements[loop+1])!
                operand = elements[loop]
                if elements[loop] == "/" && rightFloat == 0 {
                    let name = Notification.Name(rawValue: "ErrorDetection")
                    alerte = "Impossible operation"
                    let notification = Notification(name: name)
                    NotificationCenter.default.post(notification)
                    result = ""
                    priorityOperant = true
                } else {
                    result = results.resultOperation(left: leftFloat, operand: operand, right: rightFloat)
                    for _ in 0...2 {
                        elements.remove(at: loop-1)
                        if loop >= elements.count {
                            loop = elements.count
                        }
                    }
                    if loop == elements.count {
                        elements.append(String(result))
                    } else {
                        elements.insert(String(result), at: loop-1)
                        loop -= 1
                    }
                }
            }
            loop += 1
        }
        return elements
    }

    func noPriorityCalculation(elements: inout [String]) -> [String] {
        longElements = elements.count
        for inde in 0..<elements.count where elements[inde] == "+" || elements[inde] == "-" {
            if firstPassage == 0 {
                leftFloat = Double(elements[inde-1])!; firstPassage += 1
            }
            operand = elements[inde]
            if secondTime {
                leftFloat = Double(result)!
            }
            if firstPassage == 1 {
                rightFloat = Double(elements[inde+1])!; secondTime = true
            }
            if leftFloat != 0 && rightFloat != 0 {
                result = results.resultOperation(left: leftFloat, operand: operand, right: rightFloat)
            }
            if longElements-1 == inde && inde != 0 {
                rightFloat = Double(elements[inde])!
                result = results.resultOperation(left: leftFloat, operand: operand, right: rightFloat)
            }
        }
        return elements
    }

    func memoryButton(tag: Int) {
        var resulte = 0.0
        switch tag {
        case 1:
            if Double(result)! < 0 {
                memoryPlus = -Double(result)!
            } else {
                memoryPlus = Double(result)!
            }
        case 2:
            if Double(result)! > 0 {
                memoryMinus = -Double(result)!
            } else {
                memoryMinus = Double(result)!
            }
        case 3:
            resulte = memoryPlus + memoryMinus
            result = String(resulte)
            memoryPlus = 0.0; memoryMinus = 0.0
        default:
            break
        }
    }
}
