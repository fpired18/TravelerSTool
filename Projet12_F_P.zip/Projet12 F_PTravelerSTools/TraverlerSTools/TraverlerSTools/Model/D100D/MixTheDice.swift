//
//  MixTheDice.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 03/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
import AVFoundation

class MixTheDice {

    // MARK: - Properties
    var soundDieUsage: AVAudioPlayer = AVAudioPlayer()
    var listOfResults = [Int]()

     // MARK: - Methods
    func calculatingRollsOfDice(numberOfDice: Int, numberOfFace: Int) -> ([Int], Int) {
        var totalValueOfTheFaces = 0
        var valueOfFace = 0
        do {
            let audioPath = Bundle.main.path(forResource: "RemueLanceDé", ofType: "mp3")
            try soundDieUsage = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
        } catch {
            print("error")
        }
        soundDieUsage.play()

        for _ in 1...numberOfDice {
            repeat {
                valueOfFace = Int(arc4random_uniform(UInt32(numberOfFace)))
            } while valueOfFace == 0

            if valueOfFace != 0 {
                listOfResults.append(valueOfFace)
                totalValueOfTheFaces += valueOfFace
            }
        }
        return (listOfResults, totalValueOfTheFaces)
    }
}
