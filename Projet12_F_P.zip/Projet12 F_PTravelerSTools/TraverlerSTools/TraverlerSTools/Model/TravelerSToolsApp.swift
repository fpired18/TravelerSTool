//
//  TravelerSToolsSession.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 17/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

struct TravelerSToolsApp {
    static let accessKey = "6f98aec90ca7e3c372d70db320c87243"
    static let apiKey = "AIzaSyAQeL63KoAyMVQvlL7nBVIxYDP-RHnWG1c"
    static let apiKeyWeather = "09b297ea821fd2b97d5ef799852b278e"
}
