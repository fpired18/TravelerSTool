//
//  TranslateStruct.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

struct Translate: Decodable {
    var data: Data
}

struct Data: Decodable {
    var translations: [Translations]
}

struct Translations: Decodable {
    var translatedText: String
    var detectedSourceLanguage: String
}
