//
//  TranslateService.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

class TranslateService {

    // MARK: - Properties
    let translateUrl = "https://translation.googleapis.com/language/translate/v2"
    private let apiKey = "AIzaSyAQeL63KoAyMVQvlL7nBVIxYDP-RHnWG1c"
    var valueEntered = ""
    var choiceLanguage = ""
    var abbreviationLanguage = ""
    var targetLanguageCode: String?
    let languages = ["albanais": "sq", "allemand": "de", "anglais": "en", "arabe": "ar", "bosnien": "bs",
                     "bulgare": "bg", "chinois": "zh", "croate": "hr", "danois": "da", "espagnol": "es",
                     "estonien": "et", "français": "fr", "grec": "el", "hongrois": "hu", "irlandais": "ga",
                     "islandais": "is", "italien": "it", "japonais": "ja", "kurde": "ku", "lituanien": "lt",
                     "néerlandais": "nl", "portugais": "pt", "russe": "ru", "suedois": "sv" ]

    let languagesPossible = ["albanais", "allemand", "anglais", "arabe", "bosnien", "bulgare", "chinois", "croate",
                             "danois", "espagnol", "estonien", "français", "grec", "hongrois", "irlandais", "islandais",
                             "italien", "japonais", "kurde", "lituanien", "portugais", "russe", "suedois"]

    private let translateSession: TravelersSToolsProtocol

    init(translateSession: TravelersSToolsProtocol = TravelersSToolsSession()) {
        self.translateSession = translateSession
    }

    // MARK: - Methods
    func getTranslate(completionHandler: @escaping (Bool, Translate?) -> Void) {
        for (language, abbreviation) in languages where language == choiceLanguage {
            abbreviationLanguage = abbreviation
        }
        var urlParams = [String: String]()
        urlParams["key"] = TravelerSToolsApp.apiKey
        urlParams["q"] = valueEntered
        urlParams["target"] = abbreviationLanguage //Locale.current.languageCode ?? "en"
        urlParams["format"] = "text"

        if var components = URLComponents(string: translateUrl) {
            components.queryItems = [URLQueryItem]()
            for(key, value) in urlParams {
                components.queryItems?.append(URLQueryItem(name: key, value: value))
            }

            if let url = components.url {
                self.translateSession.request(url: url) { response in
                    switch response.result {
                    case .success:
                        guard response.response?.statusCode == 200 else {
                            completionHandler(false, nil)
                            return
                        }
                        guard let data = response.data, response.error == nil else {
                            completionHandler(false, nil)
                            return
                        }
                       //Json decoded, put its contents in RecipeStruct after returning with the completionHandler
                        guard let recipeResponse = try? JSONDecoder().decode(Translate.self, from: data) else {
                            completionHandler(false, nil)
                            return
                        }
                        completionHandler(true, recipeResponse)
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
}
