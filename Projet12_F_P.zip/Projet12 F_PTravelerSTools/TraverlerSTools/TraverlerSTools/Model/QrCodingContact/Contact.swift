//
//  Contact.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 17/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
import CoreData

class Contact: NSManagedObject {
    static var all: [Contact] {
        let request: NSFetchRequest<Contact> = Contact.fetchRequest()
        guard let recipes = try? AppDelegate.viewContext.fetch(request) else {
            return []
        }
        return recipes
    }

    // MARK: - Methods
    static func deleteAll(viewContext: NSManagedObjectContext = AppDelegate.viewContext) {
        let viewContext = AppDelegate.viewContext
        Contact.all.forEach({ viewContext.delete($0) })
        try? viewContext.save()
    }

    static func delete(lastName: String, viewContext: NSManagedObjectContext = AppDelegate.viewContext) {
        let request: NSFetchRequest<Contact> = Contact.fetchRequest()
        for index in 0..<Contact.all.count {
            print("Voici index \(index) et RecipeFavorite.all.count \(Contact.all.count)")
            request.predicate = NSPredicate(format: "lastName = %@", lastName)
            guard let record = try? viewContext.fetch(request) else { return }
            guard let recipe = record.first else { return }
            viewContext.delete(recipe)
        }
        try? viewContext.save()
    }

    static func save(recordContact: RecordContact, viewContext: NSManagedObjectContext = AppDelegate.viewContext) {
        let contact = Contact(context: viewContext)
        contact.address = recordContact.address
        contact.city = recordContact.city
        contact.email = recordContact.email
        contact.firstName = recordContact.firstName
        contact.lastName = recordContact.lastName
        contact.phone = recordContact.phone
        contact.postalCode = recordContact.postalCode
        try? viewContext.save()
    }

    static func contactAlreadyRecord(lastName: String,
                                     viewContext: NSManagedObjectContext = AppDelegate.viewContext) -> Bool {
        let request: NSFetchRequest<Contact> = Contact.fetchRequest()
        request.predicate = NSPredicate(format: "lastName = %@", lastName)
        guard let contact = try? viewContext.fetch(request) else { return false }
        if contact.isEmpty {
            return false
        }
        return true
    }
}
