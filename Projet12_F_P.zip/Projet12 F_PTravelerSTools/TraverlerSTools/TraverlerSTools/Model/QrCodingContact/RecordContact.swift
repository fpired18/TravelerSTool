//
//  RecordContact.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 17/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

class RecordContact {
    var lastName = ""; var firstName = ""; var address = ""; var postalCode = ""
    var city = ""; var phone = ""; var email = ""

    func generateQRCode(recordContact: RecordContact) -> String {
        let concatenation1 = recordContact.lastName + " " + recordContact.firstName + "\nAdresse: "
        let concatenation2 = recordContact.address + "\nC.P.: " + recordContact.postalCode + "\nVille: "
        let concatenation3 = recordContact.city + "\nTel: " + recordContact.phone + "\nMail: " + recordContact.email
        let concatenation = concatenation1 + concatenation2 + concatenation3
        return concatenation
    }

    func controleSeizure(enteredWord: String?) -> String {
        var correctWord = ""
        guard let wordEntered = enteredWord else { return "" }
        if wordEntered != "" && wordEntered != "´" {
            correctWord = wordEntered.trimmingCharacters(in: .whitespacesAndNewlines)
            correctWord = correctWord.folding(options: .diacriticInsensitive, locale: .current)
            //correctWord = correctWord.components(separatedBy: CharacterSet.alphanumerics.inverted).joined()
        }
        return correctWord
    }
}
