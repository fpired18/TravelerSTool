//
//  ChangeService.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
import Alamofire

class ChangeService {

    // MARK: - Properties
    let changeUrl = "http://data.fixer.io/api/latest?"
    var valueEntered = 0.0
    var valueReturn = 0.0
    var nationalityChange = ""
    let listOfNationalId = ["AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT",
                            "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BRL", "BSD", "BTC", "BTN", "BWP", "BYN", "BYR",
                            "BZD", "CAD", "CDF", "CHF", "CLF", "CLP", "CNY", "COP", "CRC", "CUC", "CUP", "CVE", "CZK",
                            "DJF", "DKK", "DOP", "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "GBP", "GEL", "GGP",
                            "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR", "ILS",
                            "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD", "JOD", "JPY", "KES", "KGS", "KHR", "KMF",
                            "KPW", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LTL", "LVL", "LYD",
                            "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRO", "MUR", "MVR", "MWK", "MXN", "MYR",
                            "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR",
                            "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD",
                            "SHP", "SLL", "SOS", "SRD", "STD", "SVC", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP",
                            "TRY", "TTD", "TWD", "TZS", "UAH", "UGX", "USD", "UYU", "UZS", "VEF", "VND", "VUV", "WST",
                            "XAF", "XAG", "XAU", "XCD", "XDR", "XOF", "XPF", "YER", "ZAR", "ZMK", "ZMW", "ZWL"]

    private let changeSession: TravelersSToolsProtocol

    init(changeSession: TravelersSToolsProtocol = TravelersSToolsSession()) {
        self.changeSession = changeSession
    }

    // MARK: - Methods
    func getChange(completionHandler: @escaping (Bool, Quote?) -> Void) {
        var urlParams = [String: String]()
        urlParams["access_key"] = TravelerSToolsApp.accessKey
        urlParams["symbols"] = nationalityChange

        if var components = URLComponents(string: changeUrl) {
            components.queryItems = [URLQueryItem]()
            for(keys, value) in urlParams {
                components.queryItems?.append(URLQueryItem(name: keys, value: value))
            }
            if let url = components.url {
                self.changeSession.request(url: url) { response in
                    switch response.result {
                    case .success:
                        guard response.response?.statusCode == 200 else {
                            completionHandler(false, nil)
                            return
                        }
                        guard let data = response.data, response.error == nil else {
                            completionHandler(false, nil)
                            return
                        }
                        guard let changeResponse = try? JSONDecoder().decode(Change.self, from: data) else {
                            completionHandler(false, nil)
                            return
                        }
                        let valeur = Double((changeResponse.rates?[self.nationalityChange])!)
                        self.valueReturn = self.valueEntered * valeur
                        let quote = Quote(valueEntered: self.valueEntered, returnValue: self.valueReturn)
                        completionHandler(true, quote)
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
}
