//
//  WeatherService.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

class WeatherService {

    // MARK: - Properties
    let weatherUrl = "http://api.openweathermap.org/data/2.5/group?"
    var valueEntered = ""
    var targetLanguageCode: String?
    var idCities = ""
    var idGlobal = ""
    let idCityPossible: [String] = ["Alexandrie", "Alger", "Athena", "Avignon", "Barcelona",
                                    "Berlin", "Bordeaux", "Bourges", "Brest", "Bruxelles", "Caen", "Dublin",
                                    "Frankfort", "Gap", "Geneve", "Lille", "Lyon", "Le Caire", "Londre",
                                    "Madrid", "Marrakech", "Marseille", "Mexico", "Moscou", "Nantes", "Nice",
                                    "Orange", "Orleans", "Paris", "Rabat", "Rio", "Rome", "Strasbourg",
                                    "Stockhlom", "Sydney", "Toulon", "Toulouse", "Tours", "Tunis", "Turin",
                                    "Venise"]

    // MARK: - Privates Properties
    private let idNewYork = "5128581,"
    private var found = false
    private var weatherSession: TravelersSToolsProtocol
    init(weatherSession: TravelersSToolsProtocol = TravelersSToolsSession()) {
        self.weatherSession = weatherSession
    }

    func getWeather(completionHandler: @escaping (Bool, WeatherStruct?) -> Void) {
        for (city, abbreviation) in idCity where city == valueEntered {
            print("I comming here because the value of ville is equal at : \(String(reflecting: city)) ")
            print("and that the value of valueEntered is equal at : \(String(reflecting: valueEntered))")
            idCities = abbreviation
            idGlobal = idNewYork + idCities
            found = true
        }
        guard found else {
            completionHandler(false, nil)
            return
        }
        var urlParams = [String: String]()
        urlParams["id"] = idGlobal
        urlParams["APPID"] = TravelerSToolsApp.apiKeyWeather
        urlParams["units"] = "metric"
        urlParams["lang"] = "fr"

        if var components = URLComponents(string: weatherUrl) {
            components.queryItems = [URLQueryItem]()
            for(keys, value) in urlParams {
                components.queryItems?.append(URLQueryItem(name: keys, value: value))
            }
            if let url = components.url {
                self.weatherSession.request(url: url) { response in
                    switch response.result {
                    case .success:
                        guard response.response?.statusCode == 200 else {
                            completionHandler(false, nil)
                            return
                        }
                        guard let data = response.data, response.error == nil else {
                            completionHandler(false, nil)
                            return
                        }
                        // If Json decoded, put its contents in RecipeStruct after returning with the completionHandler
                        guard let recipeResponse = try? JSONDecoder().decode(WeatherStruct.self, from: data) else {
                            completionHandler(false, nil)
                            return
                        }
                        completionHandler(true, recipeResponse)
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
}
