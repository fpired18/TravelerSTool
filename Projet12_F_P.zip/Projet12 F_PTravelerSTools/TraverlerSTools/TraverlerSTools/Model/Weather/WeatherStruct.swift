//
//  WeatherStruct.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 02/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation

struct WeatherStruct: Decodable {
    var cnt: Int
    var list: [List]
}

struct List: Decodable {
    var coord: Coord
    var sys: Sys
    var weather: [Weather]
    var main: Main
    var wind: Wind
    var clouds: Clouds
    var name: String
}

struct Weather: Decodable {
    var main: String
    var description: String
    var icon: String
}

struct Coord: Decodable {
    var lon: Double
    var lat: Double
}

struct Main: Decodable {
    var temp: Double
    var pressure: Int
    var humidity: Int
}

struct Clouds: Decodable {
    var all: Int
}

struct Wind: Decodable {
    var speed: Double
}

struct Sys: Decodable {
    var country: String
    var timezone: Int
    var sunrise: Int
    var sunset: Int
}

let idCity: [String: String] = ["Alexandrie": "2997870", "Alger": "5145374", "Athena": "5711861", "Londres": "3846616",
                                "Paris": "2988507", "Madrid": "3117735", "Rome": "6539761", "Turin": "3165524",
                                "Venise": "3033122", "Genève": "3378644", "Berlin": "2950159", "Bruxelles": "5934438",
                                "Dublin": "2964574", "Barcelona": "3128760", "Frankfort": "4292188",
                                "Stockhlom": "2673730", "Moscou": "2972315", "Sydney": "2147714", "Rio": "4893392",
                                "Mexico": "4398103", "Tunis": "2464470", "Le Caire": "2973485", "Rabat": "2538474",
                                "Marrakech": "6547285", "Bordeaux": "3031582", "Bourges": "6454979",
                                "Nantes": "2990969", "Strasbourg": "2973783", "Lyon": "2996944", "Marseille": "2995469",
                                "Nice": "6454924", "Toulon": "4913799", "Lille": "2998324", "Orleans": "3455784",
                                "Toulouse": "2972315", "Gap": "3016702", "Caen": "3029241", "Avignon": "6455379",
                                "Orange": "5379513", "Brest": "629634", "Tours": "2972191"]
