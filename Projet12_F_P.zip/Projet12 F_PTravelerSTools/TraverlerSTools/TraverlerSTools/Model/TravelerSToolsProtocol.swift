//
//  TravelerSToolsProtocol.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
import Alamofire

protocol TravelersSToolsProtocol {
    func request(url: URL, completionHandler: @escaping (DataResponse<Any>) -> Void)
}
