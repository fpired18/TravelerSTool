//
//  TravelersSToolsSession.swift
//  TraverlerSTools
//
//  Created by Frédéric PICHOT on 11/12/2019.
//  Copyright © 2019 Frédéric PICHOT. All rights reserved.
//

import Foundation
import Alamofire

class TravelersSToolsSession: TravelersSToolsProtocol {
    func request(url: URL, completionHandler: @escaping (DataResponse<Any>) -> Void) {
        Alamofire.request(url).responseJSON { response in
            completionHandler(response)
        }
    }
}
